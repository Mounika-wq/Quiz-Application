package com.example.quizapplication;

public class Question {
    public String questions[] = {
            "Which is a programming language?",
            "Which is the platform for developing android applications?",
            "Android studio uses which programming language?",
    };
    public String[][] choices = {
            {"HTML", "CSS", "Javascript", "PHP"},
    {"Andriod Studio", "Html", "Php", "Python"},
            {"HTML", "Php", "Java", "Python"}
    };
    public  String correctAnswer[] = {
            "PHP","Andriod Studio","Java"
    };
    public  String getQuestion(int a){
        String question = questions[a];
        return question;
    }
    public String getchoice1(int a){
        String choice = choices[a][3];
        return choice;
    }
    public String getchoice2(int a){
        String choice = choices[a][0];
        return choice;
    }
    public String getchoice3(int a){
        String choice = choices[a][2];
        return choice;
    }
    public String getchoice4(int a){
        String choice = choices[a][2];
        return choice;
    }
    public String getCorrectAnswer(int a){
        String answer = correctAnswer[a];
        return answer;
    }


}
